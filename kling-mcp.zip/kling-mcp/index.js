#!/usr/bin/env node

/**
 * Kling AI MCP Server
 * Connects Claude to Kling AI for image-to-video and text-to-video generation
 *
 * Setup:
 *   1. Get your API key from https://klingai.com (Developer section)
 *   2. Set env vars: KLING_ACCESS_KEY and KLING_SECRET_KEY
 *   3. Add to Claude Desktop config (see README.md)
 */

import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
} from "@modelcontextprotocol/sdk/types.js";
import axios from "axios";
import jwt from "jsonwebtoken";

// ── Config ──────────────────────────────────────────────────────────────────
const ACCESS_KEY = process.env.KLING_ACCESS_KEY || "";
const SECRET_KEY = process.env.KLING_SECRET_KEY || "";
const BASE_URL   = "https://api-beijing.klingai.com";

// ── JWT Token Generator ──────────────────────────────────────────────────────
function generateToken() {
  if (!ACCESS_KEY || !SECRET_KEY) {
    throw new Error(
      "Missing KLING_ACCESS_KEY or KLING_SECRET_KEY environment variables. " +
      "Get your keys from https://klingai.com developer dashboard."
    );
  }
  const payload = {
    iss: ACCESS_KEY,
    exp: Math.floor(Date.now() / 1000) + 1800, // 30 min expiry
    nbf: Math.floor(Date.now() / 1000) - 5,
  };
  return jwt.sign(payload, SECRET_KEY, {
    algorithm: "HS256",
    header: { alg: "HS256", typ: "JWT" },
  });
}

// ── Axios helper ─────────────────────────────────────────────────────────────
async function klingRequest(method, path, data = null) {
  const token = generateToken();
  const config = {
    method,
    url: `${BASE_URL}${path}`,
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
    },
  };
  if (data) config.data = data;
  const res = await axios(config);
  return res.data;
}

// ── Poll for task completion ──────────────────────────────────────────────────
async function pollTask(taskId, endpoint, maxWaitMs = 300000) {
  const start = Date.now();
  const interval = 8000; // poll every 8 seconds

  while (Date.now() - start < maxWaitMs) {
    await new Promise((r) => setTimeout(r, interval));
    const result = await klingRequest("GET", `${endpoint}/${taskId}`);
    const task = result?.data?.task_status || result?.data?.status;

    if (task === "succeed" || task === "completed") {
      return result;
    }
    if (task === "failed" || task === "error") {
      throw new Error(
        `Task failed: ${result?.data?.task_status_msg || "Unknown error"}`
      );
    }
    // still processing — keep polling
  }
  throw new Error("Task timed out after 5 minutes. Check Kling dashboard for status.");
}

// ── MCP Server ────────────────────────────────────────────────────────────────
const server = new Server(
  { name: "kling-ai", version: "1.0.0" },
  { capabilities: { tools: {} } }
);

// ── Tool Definitions ──────────────────────────────────────────────────────────
server.setRequestHandler(ListToolsRequestSchema, async () => ({
  tools: [
    {
      name: "image_to_video",
      description:
        "Generate a video from an image using Kling AI. " +
        "Upload a product photo URL and describe the motion/animation you want. " +
        "Returns a URL to download the generated video.",
      inputSchema: {
        type: "object",
        properties: {
          image_url: {
            type: "string",
            description: "Public HTTPS URL of the image to animate",
          },
          prompt: {
            type: "string",
            description:
              "Describe the motion and style. E.g. 'Cinematic slow rotation of a gold cross chain, dramatic dark lighting, light rays catching the metal'",
          },
          negative_prompt: {
            type: "string",
            description: "Things to avoid in the video (optional)",
            default: "blurry, low quality, distorted",
          },
          duration: {
            type: "number",
            description: "Video duration in seconds (5 or 10)",
            enum: [5, 10],
            default: 5,
          },
          mode: {
            type: "string",
            description: "Generation mode: std (standard) or pro (higher quality)",
            enum: ["std", "pro"],
            default: "std",
          },
          aspect_ratio: {
            type: "string",
            description: "Output aspect ratio",
            enum: ["16:9", "9:16", "1:1"],
            default: "9:16",
          },
          model_version: {
            type: "string",
            description: "Kling model version to use",
            enum: ["kling-v1", "kling-v1-5", "kling-v2", "kling-v2-5"],
            default: "kling-v1-5",
          },
        },
        required: ["image_url", "prompt"],
      },
    },
    {
      name: "text_to_video",
      description:
        "Generate a video from a text prompt using Kling AI. " +
        "Great for creating atmospheric brand videos, backgrounds, or abstract visuals. " +
        "Returns a URL to download the generated video.",
      inputSchema: {
        type: "object",
        properties: {
          prompt: {
            type: "string",
            description:
              "Describe what you want to see. E.g. 'Dramatic dark luxury jewelry ad, gold cross chains on black velvet, cinematic lighting'",
          },
          negative_prompt: {
            type: "string",
            description: "Things to avoid in the video (optional)",
            default: "blurry, low quality, text, watermark",
          },
          duration: {
            type: "number",
            description: "Video duration in seconds (5 or 10)",
            enum: [5, 10],
            default: 5,
          },
          mode: {
            type: "string",
            description: "Generation mode: std (standard) or pro (higher quality)",
            enum: ["std", "pro"],
            default: "std",
          },
          aspect_ratio: {
            type: "string",
            description: "Output aspect ratio",
            enum: ["16:9", "9:16", "1:1"],
            default: "9:16",
          },
          model_version: {
            type: "string",
            description: "Kling model version to use",
            enum: ["kling-v1", "kling-v1-5", "kling-v2", "kling-v2-5"],
            default: "kling-v1-5",
          },
        },
        required: ["prompt"],
      },
    },
    {
      name: "check_task_status",
      description:
        "Check the status of a Kling AI video generation task. " +
        "Use this if a generation is taking a long time and you want to check progress.",
      inputSchema: {
        type: "object",
        properties: {
          task_id: {
            type: "string",
            description: "The task ID returned from image_to_video or text_to_video",
          },
          task_type: {
            type: "string",
            description: "Type of task to check",
            enum: ["image_to_video", "text_to_video"],
            default: "image_to_video",
          },
        },
        required: ["task_id"],
      },
    },
    {
      name: "list_recent_videos",
      description:
        "List your recently generated Kling AI videos with their download URLs.",
      inputSchema: {
        type: "object",
        properties: {
          task_type: {
            type: "string",
            description: "Type of tasks to list",
            enum: ["image_to_video", "text_to_video"],
            default: "image_to_video",
          },
          page_size: {
            type: "number",
            description: "Number of results to return (max 30)",
            default: 10,
          },
        },
      },
    },
  ],
}));

// ── Tool Handlers ─────────────────────────────────────────────────────────────
server.setRequestHandler(CallToolRequestSchema, async (request) => {
  const { name, arguments: args } = request.params;

  try {
    // ── IMAGE TO VIDEO ──
    if (name === "image_to_video") {
      const model = args.model_version || "kling-v1-5";
      const payload = {
        model_name: model,
        image:      args.image_url,
        prompt:     args.prompt,
        negative_prompt: args.negative_prompt || "blurry, low quality, distorted",
        cfg_scale:  0.5,
        mode:       args.mode || "std",
        duration:   String(args.duration || 5),
        aspect_ratio: args.aspect_ratio || "9:16",
      };

      const response = await klingRequest(
        "POST",
        "/v1/videos/image2video",
        payload
      );

      const taskId = response?.data?.task_id;
      if (!taskId) {
        return {
          content: [{
            type: "text",
            text: `Failed to start task. Response: ${JSON.stringify(response, null, 2)}`,
          }],
        };
      }

      // Poll until done
      const result = await pollTask(taskId, "/v1/videos/image2video");
      const videoUrl =
        result?.data?.task_result?.videos?.[0]?.url ||
        result?.data?.works?.[0]?.resource?.resource;

      return {
        content: [{
          type: "text",
          text: videoUrl
            ? `✅ Video generated successfully!\n\n📹 Download URL:\n${videoUrl}\n\nTask ID: ${taskId}\nDuration: ${args.duration || 5}s\nMode: ${args.mode || "std"}\nModel: ${model}`
            : `Task completed but no video URL found.\nFull response: ${JSON.stringify(result, null, 2)}`,
        }],
      };
    }

    // ── TEXT TO VIDEO ──
    if (name === "text_to_video") {
      const model = args.model_version || "kling-v1-5";
      const payload = {
        model_name: model,
        prompt:     args.prompt,
        negative_prompt: args.negative_prompt || "blurry, low quality, text, watermark",
        cfg_scale:  0.5,
        mode:       args.mode || "std",
        duration:   String(args.duration || 5),
        aspect_ratio: args.aspect_ratio || "9:16",
      };

      const response = await klingRequest(
        "POST",
        "/v1/videos/text2video",
        payload
      );

      const taskId = response?.data?.task_id;
      if (!taskId) {
        return {
          content: [{
            type: "text",
            text: `Failed to start task. Response: ${JSON.stringify(response, null, 2)}`,
          }],
        };
      }

      const result = await pollTask(taskId, "/v1/videos/text2video");
      const videoUrl =
        result?.data?.task_result?.videos?.[0]?.url ||
        result?.data?.works?.[0]?.resource?.resource;

      return {
        content: [{
          type: "text",
          text: videoUrl
            ? `✅ Video generated successfully!\n\n📹 Download URL:\n${videoUrl}\n\nTask ID: ${taskId}\nDuration: ${args.duration || 5}s\nMode: ${args.mode || "std"}\nModel: ${model}`
            : `Task completed but no video URL found.\nFull response: ${JSON.stringify(result, null, 2)}`,
        }],
      };
    }

    // ── CHECK TASK STATUS ──
    if (name === "check_task_status") {
      const endpoint =
        args.task_type === "text_to_video"
          ? "/v1/videos/text2video"
          : "/v1/videos/image2video";

      const result = await klingRequest("GET", `${endpoint}/${args.task_id}`);
      const status = result?.data?.task_status || result?.data?.status || "unknown";
      const videoUrl =
        result?.data?.task_result?.videos?.[0]?.url ||
        result?.data?.works?.[0]?.resource?.resource;

      let text = `Task ID: ${args.task_id}\nStatus: ${status}`;
      if (videoUrl) text += `\n\n📹 Video URL:\n${videoUrl}`;
      if (status === "processing" || status === "submitted") {
        text += "\n\nStill generating — check again in a minute.";
      }

      return { content: [{ type: "text", text }] };
    }

    // ── LIST RECENT VIDEOS ──
    if (name === "list_recent_videos") {
      const endpoint =
        args.task_type === "text_to_video"
          ? "/v1/videos/text2video"
          : "/v1/videos/image2video";

      const result = await klingRequest(
        "GET",
        `${endpoint}?pageSize=${args.page_size || 10}&pageNum=1`
      );

      const tasks = result?.data?.tasks || result?.data || [];
      if (!tasks.length) {
        return {
          content: [{ type: "text", text: "No recent videos found." }],
        };
      }

      const lines = tasks.map((t, i) => {
        const videoUrl =
          t?.task_result?.videos?.[0]?.url ||
          t?.works?.[0]?.resource?.resource ||
          "No URL yet";
        return `${i + 1}. Task: ${t.task_id}\n   Status: ${t.task_status || t.status}\n   URL: ${videoUrl}`;
      });

      return {
        content: [{
          type: "text",
          text: `Recent Kling AI videos:\n\n${lines.join("\n\n")}`,
        }],
      };
    }

    return {
      content: [{ type: "text", text: `Unknown tool: ${name}` }],
      isError: true,
    };
  } catch (err) {
    const msg = err?.response?.data
      ? JSON.stringify(err.response.data, null, 2)
      : err.message;
    return {
      content: [{ type: "text", text: `Error: ${msg}` }],
      isError: true,
    };
  }
});

// ── Start ─────────────────────────────────────────────────────────────────────
const transport = new StdioServerTransport();
await server.connect(transport);
console.error("Kling AI MCP server running");
