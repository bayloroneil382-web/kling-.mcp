#!/usr/bin/env node

/**
 * Kling AI MCP Server — HTTP/SSE mode
 * Deploy this to any hosting platform and connect via URL in Claude.ai
 *
 * Usage:
 *   PORT=3000 KLING_ACCESS_KEY=xxx KLING_SECRET_KEY=yyy node server.js
 *
 * Then add this URL to Claude.ai connectors:
 *   https://your-domain.com/mcp
 */

import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { SSEServerTransport } from "@modelcontextprotocol/sdk/server/sse.js";
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
} from "@modelcontextprotocol/sdk/types.js";
import express from "express";
import axios from "axios";
import jwt from "jsonwebtoken";

const ACCESS_KEY = process.env.KLING_ACCESS_KEY || "";
const SECRET_KEY = process.env.KLING_SECRET_KEY || "";
const BASE_URL   = "https://api-beijing.klingai.com";
const PORT       = parseInt(process.env.PORT || "3000");

// ── JWT Token Generator ──────────────────────────────────────────────────────
function generateToken() {
  if (!ACCESS_KEY || !SECRET_KEY) {
    throw new Error("Missing KLING_ACCESS_KEY or KLING_SECRET_KEY env vars");
  }
  const payload = {
    iss: ACCESS_KEY,
    exp: Math.floor(Date.now() / 1000) + 1800,
    nbf: Math.floor(Date.now() / 1000) - 5,
  };
  return jwt.sign(payload, SECRET_KEY, {
    algorithm: "HS256",
    header: { alg: "HS256", typ: "JWT" },
  });
}

// ── Kling API helper ─────────────────────────────────────────────────────────
async function klingRequest(method, path, data = null) {
  const token = generateToken();
  const config = {
    method,
    url: `${BASE_URL}${path}`,
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
    },
  };
  if (data) config.data = data;
  const res = await axios(config);
  return res.data;
}

// ── Poll for task completion ──────────────────────────────────────────────────
async function pollTask(taskId, endpoint, maxWaitMs = 300000) {
  const start    = Date.now();
  const interval = 8000;
  while (Date.now() - start < maxWaitMs) {
    await new Promise((r) => setTimeout(r, interval));
    const result = await klingRequest("GET", `${endpoint}/${taskId}`);
    const status = result?.data?.task_status || result?.data?.status;
    if (status === "succeed" || status === "completed") return result;
    if (status === "failed"  || status === "error") {
      throw new Error(`Task failed: ${result?.data?.task_status_msg || "Unknown error"}`);
    }
  }
  throw new Error("Task timed out after 5 minutes.");
}

// ── Build MCP Server instance ─────────────────────────────────────────────────
function buildMcpServer() {
  const server = new Server(
    { name: "kling-ai", version: "1.0.0" },
    { capabilities: { tools: {} } }
  );

  server.setRequestHandler(ListToolsRequestSchema, async () => ({
    tools: [
      {
        name: "image_to_video",
        description: "Generate a video from a product image URL using Kling AI. Returns a download URL for the video.",
        inputSchema: {
          type: "object",
          properties: {
            image_url: { type: "string", description: "Public HTTPS URL of the image to animate" },
            prompt: { type: "string", description: "Describe the motion. E.g. 'Cinematic slow rotation of a gold cross chain, dramatic dark lighting'" },
            negative_prompt: { type: "string", description: "Things to avoid (optional)", default: "blurry, low quality, distorted" },
            duration: { type: "number", description: "Duration in seconds", enum: [5, 10], default: 5 },
            mode: { type: "string", description: "std or pro", enum: ["std", "pro"], default: "std" },
            aspect_ratio: { type: "string", description: "Output ratio", enum: ["16:9", "9:16", "1:1"], default: "9:16" },
            model_version: { type: "string", description: "Kling model version", enum: ["kling-v1", "kling-v1-5", "kling-v2", "kling-v2-5"], default: "kling-v1-5" },
          },
          required: ["image_url", "prompt"],
        },
      },
      {
        name: "text_to_video",
        description: "Generate a video from a text prompt using Kling AI. Returns a download URL.",
        inputSchema: {
          type: "object",
          properties: {
            prompt: { type: "string", description: "Describe the video. E.g. 'Luxury dark faith jewelry ad, gold cross chains, cinematic lighting'" },
            negative_prompt: { type: "string", description: "Things to avoid (optional)", default: "blurry, low quality, text, watermark" },
            duration: { type: "number", enum: [5, 10], default: 5 },
            mode: { type: "string", enum: ["std", "pro"], default: "std" },
            aspect_ratio: { type: "string", enum: ["16:9", "9:16", "1:1"], default: "9:16" },
            model_version: { type: "string", enum: ["kling-v1", "kling-v1-5", "kling-v2", "kling-v2-5"], default: "kling-v1-5" },
          },
          required: ["prompt"],
        },
      },
      {
        name: "check_task_status",
        description: "Check the status of a Kling AI video generation task.",
        inputSchema: {
          type: "object",
          properties: {
            task_id: { type: "string", description: "Task ID returned from image_to_video or text_to_video" },
            task_type: { type: "string", enum: ["image_to_video", "text_to_video"], default: "image_to_video" },
          },
          required: ["task_id"],
        },
      },
      {
        name: "list_recent_videos",
        description: "List recently generated Kling AI videos with their download URLs.",
        inputSchema: {
          type: "object",
          properties: {
            task_type: { type: "string", enum: ["image_to_video", "text_to_video"], default: "image_to_video" },
            page_size: { type: "number", default: 10 },
          },
        },
      },
    ],
  }));

  server.setRequestHandler(CallToolRequestSchema, async (request) => {
    const { name, arguments: args } = request.params;
    try {
      if (name === "image_to_video") {
        const model = args.model_version || "kling-v1-5";
        const payload = {
          model_name: model,
          image: args.image_url,
          prompt: args.prompt,
          negative_prompt: args.negative_prompt || "blurry, low quality, distorted",
          cfg_scale: 0.5,
          mode: args.mode || "std",
          duration: String(args.duration || 5),
          aspect_ratio: args.aspect_ratio || "9:16",
        };
        const response = await klingRequest("POST", "/v1/videos/image2video", payload);
        const taskId   = response?.data?.task_id;
        if (!taskId) return { content: [{ type: "text", text: `Failed to start task: ${JSON.stringify(response)}` }] };
        const result   = await pollTask(taskId, "/v1/videos/image2video");
        const videoUrl = result?.data?.task_result?.videos?.[0]?.url || result?.data?.works?.[0]?.resource?.resource;
        return { content: [{ type: "text", text: videoUrl
          ? `✅ Video generated!\n\n📹 Download URL:\n${videoUrl}\n\nTask ID: ${taskId}\nDuration: ${args.duration || 5}s | Mode: ${args.mode || "std"} | Model: ${model}`
          : `Task done but no URL found: ${JSON.stringify(result)}` }] };
      }

      if (name === "text_to_video") {
        const model = args.model_version || "kling-v1-5";
        const payload = {
          model_name: model,
          prompt: args.prompt,
          negative_prompt: args.negative_prompt || "blurry, low quality, text, watermark",
          cfg_scale: 0.5,
          mode: args.mode || "std",
          duration: String(args.duration || 5),
          aspect_ratio: args.aspect_ratio || "9:16",
        };
        const response = await klingRequest("POST", "/v1/videos/text2video", payload);
        const taskId   = response?.data?.task_id;
        if (!taskId) return { content: [{ type: "text", text: `Failed to start task: ${JSON.stringify(response)}` }] };
        const result   = await pollTask(taskId, "/v1/videos/text2video");
        const videoUrl = result?.data?.task_result?.videos?.[0]?.url || result?.data?.works?.[0]?.resource?.resource;
        return { content: [{ type: "text", text: videoUrl
          ? `✅ Video generated!\n\n📹 Download URL:\n${videoUrl}\n\nTask ID: ${taskId}\nDuration: ${args.duration || 5}s | Mode: ${args.mode || "std"} | Model: ${model}`
          : `Task done but no URL found: ${JSON.stringify(result)}` }] };
      }

      if (name === "check_task_status") {
        const ep     = args.task_type === "text_to_video" ? "/v1/videos/text2video" : "/v1/videos/image2video";
        const result = await klingRequest("GET", `${ep}/${args.task_id}`);
        const status = result?.data?.task_status || result?.data?.status || "unknown";
        const url    = result?.data?.task_result?.videos?.[0]?.url || result?.data?.works?.[0]?.resource?.resource;
        let text = `Task: ${args.task_id}\nStatus: ${status}`;
        if (url) text += `\n\n📹 Video URL:\n${url}`;
        if (status === "processing" || status === "submitted") text += "\n\nStill generating — check again in a minute.";
        return { content: [{ type: "text", text }] };
      }

      if (name === "list_recent_videos") {
        const ep     = args.task_type === "text_to_video" ? "/v1/videos/text2video" : "/v1/videos/image2video";
        const result = await klingRequest("GET", `${ep}?pageSize=${args.page_size || 10}&pageNum=1`);
        const tasks  = result?.data?.tasks || result?.data || [];
        if (!tasks.length) return { content: [{ type: "text", text: "No recent videos found." }] };
        const lines  = tasks.map((t, i) => {
          const url = t?.task_result?.videos?.[0]?.url || t?.works?.[0]?.resource?.resource || "No URL yet";
          return `${i + 1}. ${t.task_id}\n   Status: ${t.task_status || t.status}\n   URL: ${url}`;
        });
        return { content: [{ type: "text", text: `Recent videos:\n\n${lines.join("\n\n")}` }] };
      }

      return { content: [{ type: "text", text: `Unknown tool: ${name}` }], isError: true };
    } catch (err) {
      const msg = err?.response?.data ? JSON.stringify(err.response.data, null, 2) : err.message;
      return { content: [{ type: "text", text: `Error: ${msg}` }], isError: true };
    }
  });

  return server;
}

// ── Express HTTP server with SSE ──────────────────────────────────────────────
const app = express();
app.use(express.json());

// Health check
app.get("/", (req, res) => {
  res.json({
    name: "Kling AI MCP Server",
    version: "1.0.0",
    status: "running",
    endpoint: "/mcp",
    tools: ["image_to_video", "text_to_video", "check_task_status", "list_recent_videos"],
  });
});

// Active SSE transports keyed by session ID
const transports = new Map();

// SSE connection endpoint
app.get("/mcp", async (req, res) => {
  const transport = new SSEServerTransport("/mcp/messages", res);
  const server    = buildMcpServer();
  transports.set(transport.sessionId, transport);
  res.on("close", () => transports.delete(transport.sessionId));
  await server.connect(transport);
});

// Message endpoint (client POSTs here)
app.post("/mcp/messages", async (req, res) => {
  const sessionId   = req.query.sessionId;
  const transport   = transports.get(sessionId);
  if (!transport) {
    return res.status(400).json({ error: "No active session for sessionId: " + sessionId });
  }
  await transport.handlePostMessage(req, res, req.body);
});

app.listen(PORT, () => {
  console.log(`\n✅ Kling AI MCP Server running on port ${PORT}`);
  console.log(`   Health check: http://localhost:${PORT}/`);
  console.log(`   MCP endpoint: http://localhost:${PORT}/mcp\n`);
  if (!ACCESS_KEY || !SECRET_KEY) {
    console.warn("⚠️  WARNING: KLING_ACCESS_KEY or KLING_SECRET_KEY not set!");
  }
});
